package cn.itcast.travel.web.servlet;

import cn.itcast.travel.domain.ResultInfo;
import cn.itcast.travel.domain.User;
import cn.itcast.travel.service.UserService;
import cn.itcast.travel.service.impl.UserServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.beanutils.BeanUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

@WebServlet("/registUserServlet")
public class RegistUserServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, java.io.IOException {

        // 校验验证码
        // 获取从前台输入的验证码
        String check = request.getParameter("check");
        // 从session中获取验证码
        HttpSession session = request.getSession();
        // 强转为String类型
        String checkcode_server = (String) session.getAttribute("CHECKCODE_SERVER");
        // 将验证码从session中移除，保证验证码的只能使用一次
        session.removeAttribute("CHECKCODE_SERVER");
        // 比较
        if (checkcode_server == null || !checkcode_server.equalsIgnoreCase(check)) {
            // 验证码错误
            ResultInfo info = new ResultInfo();
            info.setFlag(false);
            info.setErrorMsg("验证码错误");

            // 将info对象序列化为json，并写回客户端
            ObjectMapper mapper = new ObjectMapper();
            // 设置响应数据的格式
            response.setContentType("application/json;charset=utf-8");
            mapper.writeValue(response.getWriter(), info);

            // 结束后续的代码执行
            return;
        }

        // 1.获取数据
        Map<String, String[]> map = request.getParameterMap();

        // 2.封装对象
        User user = new User();
        try {
            // 将map集合中的数据封装到user对象的属性中
            BeanUtils.populate(user, map);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }

        // 3.调用service完成注册
        UserService service = new UserServiceImpl();
        boolean flag = service.regist(user);

        // 创建一个结果集对象，用来存储响应给前台的数据
        ResultInfo info = new ResultInfo();
        // 4.响应结果
        if (flag) {
            // 注册成功
            info.setFlag(true);
        } else {
            // 注册失败
            info.setFlag(false);
            info.setErrorMsg("注册失败！");
        }

        // 将info对象序列化为json，并写回客户端
        ObjectMapper mapper = new ObjectMapper();
        // 设置conten-type，也就是响应数据的格式为json
        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getWriter(), info);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, java.io.IOException {
        this.doPost(request, response);
    }
}
