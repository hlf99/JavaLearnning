package cn.itcast.travel.service.impl;

import cn.itcast.travel.dao.CategoryDao;
import cn.itcast.travel.dao.impl.CategoryDaoImpl;
import cn.itcast.travel.domain.Category;
import cn.itcast.travel.service.CategoryService;
import cn.itcast.travel.util.JedisUtil;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.Tuple;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class CategoryServiceImpl implements CategoryService {

    private CategoryDao categoryDao = new CategoryDaoImpl();

    /**
     * 查询所有
     *
     * @return
     */
    @Override
    public List<Category> findAll() {
        // 1.从redis中查询
        // 1.1获取jedis客户端
        Jedis jedis = JedisUtil.getJedis();
        // 1.2使用sortedset排序查询
        //Set<String> categories = jedis.zrange("category", 0, -1);
        // 1.3查询sortedset中的分数（cid）和值（cname）
        // Tuple对象用来存储分数和值
        Set<Tuple> categories = jedis.zrangeWithScores("category", 0, -1);

        List<Category> cs = null;
        // 2.判断查询的集合是否为空
        if (categories == null || categories.size() == 0) {
            System.out.println("从数据库中查询......");

            // 3.如果为空，需要从数据库中查询，再将数据存入redis
            // 3.1从数据库查询
            cs = categoryDao.findAll();
            // 3.2将集合数据存储到redis中 key为category的sortedset中
            for (Category category : cs) {
                jedis.zadd("category", category.getCid(), category.getCname());
            }
        } else {
            System.out.println("从redis中查询......");

            // 4.如果categories集合不为空，将set集合中的数据存入list
            // 这里重新给cs对象赋了值，避免后面该对象调用方法出现异常
            cs = new ArrayList<Category>();
            for (Tuple tuple : categories) {
                // 创建一个Category对象，用来存储set集合中的数据
                Category category = new Category();
                category.setCname(tuple.getElement());
                category.setCid((int) tuple.getScore());
                // 将category对象存入cs的list集合
                cs.add(category);
            }
        }

        // 将cs集合返回
        return cs;
    }
}
